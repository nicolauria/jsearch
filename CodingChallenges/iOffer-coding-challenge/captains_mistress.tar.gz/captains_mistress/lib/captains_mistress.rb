require 'captains_mistress/version'

# A simple game of Captain's Mistress.
module CaptainsMistress
end
