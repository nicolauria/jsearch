class DynamicProgramming
  def initialize

  end

  def blair_nums(n)

  end

  def frog_hops_bottom_up(n)

  end

  def frog_cache_builder(n)

  end

  def knapsack(weights, values, capacity)

  end

  # Helper method for bottom-up implementation
  def knapsack_table(weights, values, capacity)

  end

  # Bonus
  def maze_solver(maze, start_pos, end_pos)
  end
end
