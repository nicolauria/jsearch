# Graphs

You will have 60 minutes to complete this assessment. Please rename your project to *your* first and last name before you zip it up and submit it on Progress Tracker. 

`firstname_lastname`

Run "bundle exec rspec" on your terminal to check how many specs you've passed.