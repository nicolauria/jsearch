require_relative 'graph'

# Kahn's
# O(|V| + |E|).
def topological_sort(vertices)
  
end

# Tarjans

def topological_sort(vertices)
  
end

def dfs!(vertex, explored, ordering)
  
end
